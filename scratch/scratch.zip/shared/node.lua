-- Utilities for "node" Values

-- Coerce a node value into a string.
--
function node:S()
   return tostring(self)
end

